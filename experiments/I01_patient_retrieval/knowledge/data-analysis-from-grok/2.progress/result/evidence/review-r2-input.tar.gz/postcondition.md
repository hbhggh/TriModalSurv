# 零训练改推理1–5：验收记录

**当前状态：代码、回归与CPU valid冒烟已通过；Claude审核因OAuth过期阻塞。整轮正式实验未完成，不能把下面所有项勾成通过。**

| 验收项 | 证据位置 | 是否通过 |
|---|---|---|
| precondition先于推理代码创建，实现门明确 | precondition.md、evidence/progress.md | [x] 是 |
| 五个固定目录均含真实model/config/分析表 | 01–05目录 | [x] 是 |
| 共享入口、选择器、报告与独立测试存在 | run.py、runtime.py、inference.py、selection.py、reporting.py、tests/ | [x] 是 |
| 原公共代码未改 | evidence/source-final.json及实施前SHA；precondition锁定基线 | [x] 是 |
| 实际部署代码与本机一致 | evidence/deployment-parity.json；35个代码/规则配置一致，远端22个AppleDouble元数据独立列明 | [x] 是 |
| 25份E0严格加载、内容唯一、来源SHA匹配 | evidence/preflight-final.json | [x] 是 |
| 45份缓存和标签/manifest核验 | evidence/preflight-final.json、valid-source.json | [x] 是 |
| 旧回归全量通过，真实NPJC不skip | evidence/tests-legacy-remote.log（68/68） | [x] 是 |
| 新规则与门禁/报告测试通过 | evidence/tests-new-remote.log（39/39） | [x] 是 |
| CPU valid前向冒烟、全原始资产前后SHA一致 | evidence/smoke-summary.md、smoke-final.json；20格、180记录、无C-index | [x] 是 |
| Claude真实只读复审 | evidence/claude-review.md；两个实际入口认证失败，无审查意见 | [ ] BLOCKED_AUTH |
| 正式valid选参58候选全部有成绩并冻结六协议 | 尚未授权，不存在selection-lock | [ ] 未跑 |
| 一次test获得600新协议+300参考格点 | 尚未授权 | [ ] 未跑 |
| 四场景同批结果、红色最佳值及两列Δ | 三份结果MD当前全部“未跑”；生成器合成验收已通过，不能冒充实验数据 | [ ] 未跑 |
| 完整正式矩阵无缺癌/seed/格点 | 尚无正式矩阵 | [ ] 未跑 |
| 不训练、不改原权重/缓存、不覆盖历史JSON | 前置指纹＋冒烟后检查；未创建训练入口或调用optimizer/backward | [x] 当前满足 |
| 不commit/push，不自动扩范围 | 执行记录 | [x] 是 |

## 停止边界

- 冒烟结束先交Claude审核，再统一收单；不在审核前宣布通过。
- 审核通过也不构成正式执行授权，valid选参与test仍待用户另行放行。
- 结果受历史test启发，只能作为探索性规则比较；未产生C-index前没有正负收益判断。
